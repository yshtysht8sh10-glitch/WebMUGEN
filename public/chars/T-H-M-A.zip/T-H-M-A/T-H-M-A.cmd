
;---------------------------------------------------------------

;-| CPU |-------------------------------------------------------

[Command]
name = "cpu1"
command = a,U,D,F,F,B,B,D,U,U
time = 1
[Command]
name = "cpu2"
command = b,U,D,F,B,F,B,D,U,D
time = 1
[Command]
name = "cpu3"
command = c,U,D,B,F,B,F,D,U,B
time = 1
[Command]
name = "cpu4"
command = x,U,D,B,F,F,B,D,U,F
time = 1
[Command]
name = "cpu5"
command = y,U,D,F,F,B,B,D,U,a
time = 1
[Command]
name = "cpu6"
command = z,U,D,F,B,F,B,D,U,b
time = 1
[Command]
name = "cpu7"
command = s,U,D,B,F,B,F,D,U,c
time = 1
[Command]
name = "cpu8"
command = b,U,D,B,F,F,B,D,U,x
time = 1
[Command]
name = "cpu9"
command = c,U,D,F,B,F,B,D,U,y
time = 1
[Command]
name = "cpu10"
command = c,U,D,B,B,F,B,D,U,y
time = 1
[Command]
name = "cpu11"
command = a,U,D,F,F,B,B,B,D,U,U
time = 1
[Command]
name = "cpu12"
command = b,U,D,F,B,F,B,B,D,U,D
time = 1
[Command]
name = "cpu13"
command = c,U,D,B,B,F,B,F,D,U,B
time = 1
[Command]
name = "cpu14"
command = x,U,D,B,F,B,F,B,D,U,F
time = 1
[Command]
name = "cpu15"
command = y,U,D,F,F,B,B,B,D,U,a
time = 1
[Command]
name = "cpu16"
command = z,U,B,D,F,B,F,B,D,U,b
time = 1
[Command]
name = "cpu17"
command = s,U,D,B,F,B,F,B,D,U,c
time = 1
[Command]
name = "cpu18"
command = b,U,D,B,F,B,F,B,D,U,x
time = 1
[Command]
name = "cpu19"
command = c,U,D,F,B,B,F,B,D,U,y
time = 1
[Command]
name = "cpu20"
command = c,U,D,B,B,B,F,B,D,U,y
time = 1
[Command]
name = "cpu21"
command = a,U,D,F,F,s,B,B,D,U,U
time = 1
[Command]
name = "cpu22"
command = b,U,s,D,F,B,F,B,D,U,D
time = 1
[Command]
name = "cpu23"
command = c,U,D,B,F,B,F,s,D,U,B
time = 1
[Command]
name = "cpu24"
command = x,U,D,B,s,F,F,B,D,U,F
time = 1
[Command]
name = "cpu25"
command = y,U,D,s,F,F,B,B,D,U,a
time = 1
[Command]
name = "cpu26"
command = z,U,D,F,B,F,s,B,D,U,b
time = 1
[Command]
name = "cpu27"
command = s,U,D,s,B,F,B,F,D,U,c
time = 1
[Command]
name = "cpu28"
command = b,U,D,B,s,F,F,B,s,D,U,x
time = 1
[Command]
name = "cpu29"
command = c,U,D,F,s,B,F,B,D,U,y
time = 1
[Command]
name = "cpu30"
command = c,U,D,B,B,F,B,s,D,U,y
time = 1
;---------------------------------------------------------------------

;-| ���K�E�Z |--------------------------------------------------------

[Command]
name = "�����ړ� (���K)"
command = D,  F, D,  F, z
time = 25

[Command]
name = "���� (����)"
command = D,  B, D,  B, s
time = 25

[Command]
name = "�����ړ� (����)"
command = D,  B, D,  B, z
time = 25

[Command]
name = "�U���� (����)"
command = D,  B, D,  B, c
time = 25

[Command]
name = "�V����"
command = ~D,  F, D,  F, x+y
time = 25

[Command]
name = "�����Z"
command = ~B,  D, F,  D, DF, a+b
time = 25

[Command]
name = "���Ay"
command = ~D,  F, D,  F, y
time = 25

[Command]
name = "���Ax"
command = ~D,  F, D,  F, x
time = 25

[Command]
name = "����̔w�ォ��R��b"
command = ~D,  B, D,  B, b
time = 25

[Command]
name = "����̔w�ォ��R��a"
command = ~D,  B, D,  B, a
time = 25

[Command]
name = "�A�qb"
command = ~D,  F, D,  F, b
time = 25

[Command]
name = "�A�qa"
command = ~D,  F, D,  F, a
time = 25

[Command]
name = "�_�[�N�l�X�t�B���K�["
command = ~D, DB, B, F, x+y
time = 25

;-| �K�E�Z |------------------------------------------------------

[Command]
name = "�_�[�N�l�X�t�B���K�[ �����t��y"
command = ~D, DB, B, F, y
time = 25

[Command]
name = "�_�[�N�l�X�t�B���K�[ �����t��x"
command = ~D, DB, B, F, x
time = 25

[Command]
name = "�{�S������ȗ���a"
command = ~D, B, U, D, a
time = 30

[Command]
name = "�{�S������ȗ���b"
command = ~D, B, U, D, b
time = 30

[Command]
name = "���Ԃ��ł̍U���i���j"
command = ~D, DB, B, y

[Command]
name = "���Ԃ��ł̍U���i��j"
command = ~D, DB, B, x

[Command]
name = "�󒆃��b�V���i���j"
command = ~D, DB, B, b

[Command]
name = "�󒆃��b�V���i��j"
command = ~D, DB, B, a

[Command]
name = "�����R��iEX�j"
command = ~D, DF, F, a+b

[Command]
name = "�����R��i���j"
command = ~D, DF, F, b

[Command]
name = "�����R��i��j"
command = ~D, DF, F, a

[Command]
name = "��]�i���j"
command = ~F, D, DF, y

[Command]
name = "��]�i��j"
command = ~F, D, DF, x

[Command]
name = "�Ռ��g�i���j"
command = ~D, DF, F, y

[Command]
name = "�Ռ��g�i��j"
command = ~D, DF, F, x

;-| �Q�񉟂��Z |-----------------------------------------------------------
[Command]
name = "Dasyu"     
command = F, F
time = 10

[Command]
name = "BakuSutep"     
command = B, B
time = 15

;-| �Q�E�R�̓��������Z |-----------------------------------------------
[Command]
name = "�W�J"
command = z+c
time = 1

[Command]
name = "recovery"
command = z
time = 1

[Command]
name = "����"
command = x+y
time = 1

[Command]
name = "�K�[�h�L�����Z��"
command = x+a
time = 1


;-| �����ƃ{�^���ŏo���Z |------------------------------------------------
[Command]
name = "�ϑ�������p���`"
command = /$B,x
time = 1

[Command]
name = "�ߋ���������p���`"
command = /$F,x
time = 1

;---
[Command]
name = "DF_z"
command = /$DF,z
time = 1

[Command]
name = "DB_z"
command = /$DB,z
time = 1

[Command]
name = "UB_z"
command = /$UB,z
time = 1

[Command]
name = "UF_z"
command = /$UF,z
time = 1

[Command]
name = "F_z"
command = /$F,z
time = 1

[Command]
name = "D_z"
command = /$D,z
time = 1

[Command]
name = "B_z"
command = /$B,z
time = 1

[Command]
name = "U_z"
command = /$U,z
time = 1
;---

;-| �{�^���ݒ�i������Ȃ��j|---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�i������Ȃ��j-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holdupfwd"
command = /$UF
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "longjump"
command = ~D, $U
time = 7

;----------------------------- ����
[Command]
name = "fwd"
command = F
time = 1

[Command]
name = "downfwd"
command = DF
time = 1

[Command]
name = "down"
command = D
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "upback"
command = UB
time = 1

[Command]
name = "up"
command = U
time = 1

[Command]
name = "upfwd"
command = UF
time = 1

[Command]
name = "Not-Neutral"
command = $U
time = 1

[Command]
name = "Not-Neutral"
command = $F
time = 1

[Command]
name = "Not-Neutral"
command = $D
time = 1

[Command]
name = "Not-Neutral"
command = $B
time = 1

;======================
[Statedef -1]
;======================
;------
;------
;===========================================================================
;------------------------| ���K�E�Z |---------------------------------------
;===========================================================================
;�����ړ� (���K)
[State -1, ChangeState]
type = ChangeState
value = 3200
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerAll = var(20) = 0
triggerall = power >= 1000
triggerall = command = "�����ړ� (���K)"
trigger1 = statetype != A
trigger1 = ctrl = 1
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerAll = var(20) = 0
triggerall = power >= 1000
triggerall = command = "�����ړ� (���K)"
trigger1 = statetype != A
trigger1 = ctrl = 1
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3200
triggerall = var(16) = 0
triggerAll = var(20) = 0
trigger1 = command = "�����ړ� (���K)"

---------------------------------------------------------------------------
;���� (����)
[State -1, ChangeState]
type = ChangeState
value = 3540
TriggerAll = Palno != 12
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 3000
triggerall = command = "���� (����)"
trigger1 = statetype != A
trigger1 = ctrl = 1
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 3000
triggerall = command = "���� (����)"
TriggerAll = Palno != 12
trigger1 = statetype != A
trigger1 = ctrl = 1
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3540
triggerall = var(16) = 0
TriggerAll = Palno != 12
trigger1 = command = "���� (����)"

---------------------------------------------------------------------------
;�����ړ� (����)
[State -1, ChangeState]
type = ChangeState
value = 3500
TriggerAll = Palno != 12
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "�����ړ� (����)"
trigger1 = statetype != A
trigger1 = ctrl = 1
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "�����ړ� (����)"
TriggerAll = Palno != 12
trigger1 = statetype != A
trigger1 = ctrl = 1
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3500
triggerall = var(16) = 0
TriggerAll = Palno != 12
trigger1 = command = "�����ړ� (����)"

---------------------------------------------------------------------------
;�U����   (����)
[State -1, ChangeState]
type = ChangeState
value = 3520
TriggerAll = Palno != 12
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "�U���� (����)"
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2= stateno=999
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "�U���� (����)"
TriggerAll = Palno != 12
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2= stateno=999
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3520
triggerall = var(16) = 0
TriggerAll = Palno != 12
trigger1 = command = "�U���� (����)"

---------------------------------------------------------------------------
;�V����
[State -1, ChangeState]
type = ChangeState
value = 3000
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�V����"
Trigger1 = Var(20) = 0
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger1 = power >= 3000
Trigger2 = Var(20) = 1
trigger2 = statetype != A
trigger2 = ctrl = 1
trigger2 = power >= 1500
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�V����"
Trigger1 = Var(20) = 0
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger1 = power >= 3000
Trigger2 = Var(20) = 1
trigger2 = statetype != A
trigger2 = ctrl = 1
trigger2 = power >= 1500
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3520
triggerall = var(16) = 0
trigger1 = command = "�V����"

;---------------------------------------------------------------------------
;�����Z
[State -1, ChangeState]
type = ChangeState
value = 3700
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 3000
triggerall = command = "�����Z" 
trigger1 = ctrl = 1
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 3000
triggerall = command = "�����Z" 
trigger1 = statetype != A
trigger1 = ctrl = 1
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 3000
triggerall = command = "�����Z" 
trigger1 = statetype = A
trigger1 = ctrl = 1
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3700
triggerall = var(16) = 0
trigger1 = command = "�����Z" 

;---------------------------------------------------------------------------
;�_�[�N�l�X�t�B���K�[ �^��
[State -1, ChangeState]
type = ChangeState
value = 3900
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�_�[�N�l�X�t�B���K�[" 
triggerall = power >= 3000
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�_�[�N�l�X�t�B���K�[" 
triggerall = power >= 3000
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3900
triggerall = var(16) = 0
trigger1 = command = "�_�[�N�l�X�t�B���K�[" 

;---------------------------------------------------------------------------
;���A�i���j
[State -1, ChangeState]
type = ChangeState
value = 3800
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "���Ay"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "���Ay"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3800
triggerall = var(16) = 0
trigger1 = command = "���Ay"

;---------------------------------------------------------------------------
;���A�i��j
[State -1, ChangeState]
type = ChangeState
value = 3850
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "���Ax"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "���Ax"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3850
triggerall = var(16) = 0
trigger1 = command = "���Ax"

---------------------------------------------------------------------------
;���E����̔w�ォ��R��i���j
[State -1, ChangeState]
type = ChangeState
value = 3120
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 1
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��b"
trigger1 = ctrl = 1
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 1
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��b"
triggerall = statetype != A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 1
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��b"
triggerall = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3120
triggerall = var(16) = 0
TriggerAll = var(19) = 1
trigger1 = command = "����̔w�ォ��R��b"

;---------------------------------------------------------------------------
;���E����̔w�ォ��R��i��j
[State -1, ChangeState]
type = ChangeState
value = 3100
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 1
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��a" 
trigger1 = ctrl = 1
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 1
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��a" 
triggerall = statetype != A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 1
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��a" 
triggerall = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3110
triggerall = var(16) = 0
TriggerAll = var(19) = 1
trigger1 = command = "����̔w�ォ��R��a"

;---------------------------------------------------------------------------
;�V�E����̔w�ォ��R��i���j
[State -1, ChangeState]
type = ChangeState
value = 3180
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��b"
trigger1 = ctrl = 1
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��b" 
triggerall = statetype != A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��b"
triggerall = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3180
triggerall = var(16) = 0
TriggerAll = var(19) = 0
trigger1 = command = "����̔w�ォ��R��b"

;---------------------------------------------------------------------------
;�V�E����̔w�ォ��R��i��j
[State -1, ChangeState]
type = ChangeState
value = 3160
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��a" 
trigger1 = ctrl = 1
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��a" 
triggerall = statetype != A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(19) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "����̔w�ォ��R��a" 
triggerall = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
trigger4= (stateno=[600,640]) && movecontact
trigger5= (stateno=[1020,1046]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3160
triggerall = var(16) = 0
TriggerAll = var(19) = 0
trigger1 = command = "����̔w�ォ��R��a"

;---------------------------------------------------------------------------
;�A�q�i��j
[State -1, ChangeState]
type = ChangeState
value = 3300
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "�A�qa" 
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "�A�qa"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3300
triggerall = var(16) = 0
trigger1 = command = "�A�qa" 

;---------------------------------------------------------------------------
;�A�q�i���j
[State -1, ChangeState]
type = ChangeState
value = 3350
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 1000
triggerall = command = "�A�qb"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,242]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = power >= 1000
triggerall = command = "�A�qb"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3350
triggerall = var(16) = 0
trigger1 = command = "�A�qb"

;---------------------------------------------------------------------------
;�_�[�N�l�X�t�B���K�[ �e��
[State -1, ChangeState]
type = ChangeState
value = 3600
TriggerAll = Var(33) = 0
TriggerAll = var(22) = 1
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = power >= 5000
triggerall = command = "�_�[�N�l�X�t�B���K�[" 
triggerall = TeamMode = single || TeamMode = turns
triggerall = enemy,TeamMode = single || enemy,TeamMode = turns
triggerall = Var(20) = 0
trigger1 = stateno = 3430

;===========================================================================
;------------------------| �K�E�Z |-----------------------------------------
;===========================================================================
;�_�[�N�l�X�t�B���K�[ �����t���i���j
[State -1, ChangeState]
type = ChangeState
value = 3400
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall =  command = "�_�[�N�l�X�t�B���K�[ �����t��y"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall =  command = "�_�[�N�l�X�t�B���K�[ �����t��y"
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3400
triggerall = var(16) = 0
trigger1 =  command = "�_�[�N�l�X�t�B���K�[ �����t��y"

;�_�[�N�l�X�t�B���K�[ �����t���i���j
[State -1, ChangeState]
type = ChangeState
value = 3401
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
TriggerAll = Var(19) = 1
triggerall =  command = "�_�[�N�l�X�t�B���K�[ �����t��y"
trigger1 = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
TriggerAll = Var(19) = 1
triggerall =  command = "�_�[�N�l�X�t�B���K�[ �����t��y"
trigger1 = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 3401
triggerall = var(17) = 0
TriggerAll = Var(19) = 1
trigger1 =  command = "�_�[�N�l�X�t�B���K�[ �����t��y"

;---------------------------------------------------------------------------
;�_�[�N�l�X�t�B���K�[ �����t���i��j
[State -1, ChangeState]
type = ChangeState
value = 3405
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�_�[�N�l�X�t�B���K�[ �����t��x" 
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�_�[�N�l�X�t�B���K�[ �����t��x" 
trigger1 = ctrl = 1
trigger1 = statetype != A
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 3405
triggerall = var(16) = 0
trigger1 =  command = "�_�[�N�l�X�t�B���K�[ �����t��x"

;�_�[�N�l�X�t�B���K�[ �����t���i��j
[State -1, ChangeState]
type = ChangeState
value = 3402
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
TriggerAll = Var(19) = 1
triggerall = command = "�_�[�N�l�X�t�B���K�[ �����t��x" 
trigger1 = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
TriggerAll = Var(19) = 1
triggerall = command = "�_�[�N�l�X�t�B���K�[ �����t��x" 
trigger1 = statetype = A
trigger1 = ctrl = 1
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 3402
triggerall = var(17) = 0
TriggerAll = Var(19) = 1
trigger1 =  command = "�_�[�N�l�X�t�B���K�[ �����t��x"

;---------------------------------------------------------------------------
;���Ԃ��ł̍U���i���j
[State -1, ChangeState]
type = ChangeState
value = 1078
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "���Ԃ��ł̍U���i���j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact = 1
trigger3= (stateno=[230,232]) && movecontact = 1
trigger4= stateno = 240 && movecontact = 1
trigger5= (stateno=[400,440]) && movecontact = 1
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "���Ԃ��ł̍U���i���j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact = 1
trigger3= (stateno=[230,232]) && movecontact = 1
trigger4= stateno = 240 && movecontact = 1
trigger5= (stateno=[400,440]) && movecontact = 1
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1078
triggerall = var(16) = 0
trigger1 = command = "���Ԃ��ł̍U���i���j"

;---------------------------------------------------------------------------
;���Ԃ��ł̍U���i��j
[State -1, ChangeState]
type = ChangeState
value = 1070
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "���Ԃ��ł̍U���i��j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "���Ԃ��ł̍U���i��j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1070
triggerall = var(16) = 0
trigger1 = command = "���Ԃ��ł̍U���i��j"

;---------------------------------------------------------------------------
;�󒆃��b�V���i���j
[State -1, ChangeState]
type = ChangeState
value = 1045
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�󒆃��b�V���i���j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�󒆃��b�V���i���j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 1045
triggerall = var(17) = 0
trigger1 = command = "�󒆃��b�V���i���j"

;---------------------------------------------------------------------------
;�󒆃��b�V���i��j
[State -1, ChangeState]
type = ChangeState
value = 1040
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�󒆃��b�V���i��j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�󒆃��b�V���i��j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 1040
triggerall = var(17) = 0
trigger1 = command = "�󒆃��b�V���i��j"

;---------------------------------------------------------------------------
;�����R��iEX�j
[State -1, ChangeState]
type = ChangeState
value = 1035
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�����R��iEX�j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�����R��iEX�j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 1035
triggerall = var(17) = 0
trigger1 = command = "�����R��iEX�j"

;---------------------------------------------------------------------------
;�����R��i���j
[State -1, ChangeState]
type = ChangeState
value = 1030
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�����R��i���j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�����R��i���j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 1030
triggerall = var(17) = 0
trigger1 = command = "�����R��i���j"

;---------------------------------------------------------------------------
;�����R��i��j
[State -1, ChangeState]
type = ChangeState
value = 1020
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�����R��i��j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�����R��i��j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 1020
triggerall = var(17) = 0
trigger1 = command = "�����R��i��j"

;---------------------------------------------------------------------------
;���b�V���i���j
[State -1, ChangeState]
type = ChangeState
value = 1018
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�����R��i���j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�����R��i���j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1018
triggerall = var(16) = 0
trigger1 = command = "�����R��i���j"

;---------------------------------------------------------------------------
;���b�V���i��j
[State -1, ChangeState]
type = ChangeState
value = 1010
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�����R��i��j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�����R��i��j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1010
triggerall = var(16) = 0
trigger1 = command = "�����R��i��j"

;---------------------------------------------------------------------------
;��]�i���j
[State -1, ChangeState]
type = ChangeState
value = 1055
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "��]�i���j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "��]�i���j"
trigger1 = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1055
triggerall = var(16) = 0
trigger1 = command = "��]�i���j"

;��]�󒆁i���j
[State -1, ChangeState]
type = ChangeState
value = 1061
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "��]�i���j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "��]�i���j"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 1061
triggerall = var(17) = 0
trigger1 = command = "��]�i���j"

;---------------------------------------------------------------------------
;��]�i��j
[State -1, ChangeState]
type = ChangeState
value = 1050
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "��]�i��j"
triggerall = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
trigger6= (stateno=[600,640]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "��]�i��j"
triggerall = statetype != A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
trigger6= (stateno=[600,640]) && movecontact
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1050
triggerall = var(16) = 0
trigger1 = command = "��]�i��j"

;��]�i��j
[State -1, ChangeState]
type = ChangeState
value = 1054
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "��]�i��j"
triggerall = statetype = A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
trigger6= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "��]�i��j"
triggerall = statetype = A
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4= stateno = 240 && movecontact
trigger5= (stateno=[400,440]) && movecontact
trigger6= (stateno=[600,640]) && movecontact
;�󒆃��o�T
[State -1, Varset]
type = Varset
var(17) = 1054
triggerall = var(17) = 0
trigger1 = command = "��]�i��j"

;---------------------------------------------------------------------------
;�Ռ��g�i���j
[State -1, ChangeState]
type = ChangeState
value = 1005
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�Ռ��g�i���j"
trigger1 = statetype != A
trigger1 = ctrl
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�Ռ��g�i���j"
trigger1 = statetype != A
trigger1 = ctrl
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1005
triggerall = var(16) = 0
trigger1 = command = "�Ռ��g�i���j"

;---------------------------------------------------------------------------
;�Ռ��g�i��j
[State -1, ChangeState]
type = ChangeState
value = 1000
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall = command = "�Ռ��g�i��j"
trigger1 = statetype != A
trigger1 = ctrl
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 0 || fvar(12) <= 5
triggerall = command = "�Ռ��g�i��j"
trigger1 = statetype != A
trigger1 = ctrl
;�n�ナ�o�T
[State -1, Varset]
type = Varset
var(16) = 1000
triggerall = var(16) = 0
trigger1 = command = "�Ռ��g�i��j"

;===========================================================================
;===========================================================================
;�W�J
[State -1, ChangeState]
type = ChangeState
value = 4999
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = statetype = S
trigger1 = command = "�W�J"
trigger1 = ctrl

[State -1, ChangeState]
type = ChangeState
value = 4998
TriggerAll = Var(40) = 1
TriggerAll = Var(33) = 0
triggerall = statetype = S
trigger1 = command = "�W�J"
trigger1 = ctrl

;---------------------------------------------------------------------------
;�ǒ���t��
[State -1, ChangeState]
type = ChangeState
value = 110
TriggerAll = Var(33) = 0
trigger1 = command = "c"
trigger1 = statetype = A
trigger1 = BackEdgeBodyDist < 11
trigger1 = ctrl

;---------------------------------------------------------------------------
;�_�b�V��
[State -1, ChangeState]
type = ChangeState
value = 100
TriggerAll = Var(33) = 0
trigger1 = command = "Dasyu"
trigger1 = statetype = S
trigger1 = ctrl
trigger2= stateno = 1074 && movehit
trigger2= command = "holdfwd"
trigger2= p2stateno = 280

;---------------------------------------------------------------------------
;��ރ_�b�V��
[State -1, ChangeState]
type = ChangeState
value = 105
TriggerAll = Var(33) = 0
triggerall = command = "BakuSutep"
triggerall = statetype = S
trigger1= stateno != 105
trigger1 = ctrl

;---------------------------------------------------------------------------
;�O���󒆃_�b�V��
[State -1, ChangeState]
type = ChangeState
value = 7020
TriggerAll = Var(8) <= 0
TriggerAll = Var(40) = 1
TriggerAll = Var(33) = 0
trigger1 = command = "Dasyu"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;����󒆃_�b�V��
[State -1, ChangeState]
type = ChangeState
value = 7030
TriggerAll = Var(9) <= 0
TriggerAll = Var(40) = 1
TriggerAll = Var(33) = 0
triggerall = command = "BakuSutep"
triggerall = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1, ChangeState]
type = ChangeState
value = 700
TriggerAll = Var(33) = 0
triggerall = statetype = S
trigger1 = command = "����"
trigger1 = ctrl

;---------------------------------------------------------------------------
;�K�[�h�L�����Z��
[State -1, ChangeState]
type = ChangeState
value = 920
TriggerAll = Var(33) = 0
triggerall = command = "�K�[�h�L�����Z��"
triggerall = command = "holdfwd"
triggerall = fvar(12) < 5
trigger1 = stateno = 150
trigger2 = stateno = 151

;---------------------------------------------------------------------------
;�ϑ�������p���`
[State -1, ChangeState]
type = ChangeState
value = 205
TriggerAll = Var(33) = 0
triggerall = command = "�ϑ�������p���`"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2= stateno = 200 && movecontact
trigger3= stateno = 203 && movecontact
trigger4 = stateno = 101
trigger5 = stateno = [103,104]
trigger6 = stateno= 400 && movecontact

;---------------------------------------------------------------------------
;�ߋ���������p���`
[State -1, ChangeState]
type = ChangeState
value = 200
TriggerAll = Var(33) = 0
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = p2bodydist X <= 20
triggerall = p2bodydist Y = 0
trigger1 = p2statetype != A
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 101
trigger3 = stateno = [103,104]

;---------------------------------------------------------------------------
;������p���`
[State -1, ChangeState]
type = ChangeState
value = 203
TriggerAll = Var(33) = 0
triggerall = command = "x"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 101
trigger3 = stateno = [103,104]

;---------------------------------------------------------------------------
;�������p���`
[State -1, ChangeState]
type = ChangeState
value = 210
TriggerAll = Var(33) = 0
triggerall = command = "y"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,205]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4 = stateno = 101
trigger5 = stateno = [103,104]
trigger6 = stateno= 400 && movecontact

;---------------------------------------------------------------------------
;������L�b�N
[State -1, ChangeState]
type = ChangeState
value = 230
TriggerAll = Var(33) = 0
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = p2bodydist X >= 20
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,205]) && movecontact
trigger3 = stateno = 101
trigger4 = stateno = [103,104]
trigger6 = stateno= 400 && movecontact

;---------------------------------------------------------------------------
;�ߋ���������L�b�N
[State -1, ChangeState]
type = ChangeState
value = 232
TriggerAll = Var(33) = 0
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = p2bodydist X <= 20
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,205]) && movecontact
trigger3 = stateno = 101
trigger4 = stateno = [103,104]
trigger5 = stateno= 400 && movecontact

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, ChangeState]
type = ChangeState
value = 240
TriggerAll = Var(33) = 0
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,210]) && movecontact
trigger3= (stateno=[230,232]) && movecontact
trigger4 = stateno = 101
trigger5 = stateno = [103,104]
trigger6 = stateno= 400 && movecontact

;---------------------------------------------------------------------------
;����
[State -1, ChangeState]
type = ChangeState
value = 195
TriggerAll = Var(33) = 0
triggerall = command = "start"
trigger1 = statetype != A
trigger1 = ctrl

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1, ChangeState]
type = ChangeState
value = 400
TriggerAll = Var(33) = 0
triggerall = command = "x"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 101
trigger3 = stateno = [103,104]

;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1, ChangeState]
type = ChangeState
value = 410
TriggerAll = Var(33) = 0
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2= stateno = 400 && movecontact
trigger3= stateno = 430 && movecontact
trigger4 = stateno = 101
trigger5 = stateno = [103,104]

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1, ChangeState]
type = ChangeState
value = 430
TriggerAll = Var(33) = 0
triggerall = command = "a"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2= stateno = 400 && movecontact
trigger3 = stateno = 101
trigger4 = stateno = [103,104]

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1, ChangeState]
type = ChangeState
value = 440
TriggerAll = Var(33) = 0
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2= (stateno=[400,430]) && movecontact
trigger3 = stateno = 101
trigger4 = stateno = [103,104]

;---------------------------------------------------------------------------
;�󒆎�p���`
[State -1, ChangeState]
type = ChangeState
value = 600
TriggerAll = Var(33) = 0
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆋��p���`
[State -1, ChangeState]
type = ChangeState
value = 610
TriggerAll = Var(33) = 0
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= stateno = 600 && movecontact
trigger3= stateno = 630 && movecontact
;---------------------------------------------------------------------------
;�󒆎�L�b�N
[State -1, ChangeState]
type = ChangeState
value = 630
TriggerAll = Var(33) = 0
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= stateno = 600 && movecontact

;---------------------------------------------------------------------------
;�󒆋��L�b�N
[State -1, ChangeState]
type = ChangeState
value = 640
TriggerAll = Var(33) = 0
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,630]) && movecontact

;===========================================================================
;------------------------| �����ړ� |---------------------------------------
;===========================================================================
; �����ړ� (��O��)
[State -1, ChangeState]
type = ChangeState
value = 6070
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "UF_z" 
triggerall = var(12) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=3850) && MoveGuarded
trigger4=  stateno = 40
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "UF_z" 
triggerall = var(12) = 1
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact

;---------------------------------------------------------------------------
; �����ړ� (����)
[State -1, ChangeState]
type = ChangeState
value = 6050
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "UB_z" 
triggerall = var(12) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=3850) && MoveGuarded
trigger4=  stateno = 40
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "UB_z" 
triggerall = var(12) = 1
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact

;---------------------------------------------------------------------------
; �����ړ� (���)
[State -1, ChangeState]
type = ChangeState
value = 6060
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "U_z"
triggerall = var(12) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=3850) && MoveGuarded
trigger4=  stateno = 40
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "U_z"
triggerall = var(12) = 1
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact

;---------------------------------------------------------------------------
; �����ړ� (�O��)
[State -1, ChangeState]
type = ChangeState
value = 6000
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "F_z" 
triggerall = var(12) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=3850) && MoveGuarded
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "F_z" 
triggerall = var(12) = 1
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact

;---------------------------------------------------------------------------
; �����ړ� (���)
[State -1, ChangeState]
type = ChangeState
value = 6001
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "B_z"
triggerall = var(12) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact
trigger3= (stateno=3850) && MoveGuarded
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "B_z"
triggerall = var(12) = 1
trigger1 = statetype = S
trigger1 = ctrl
trigger2= (stateno=[200,241]) && movecontact

;---------------------------------------------------------------------------
; �����ړ� 
[State -1, ChangeState]
type = ChangeState
value = 5999
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "z" 
triggerall = var(12) = 0
trigger1 = statetype = S
trigger1 = ctrl
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "z" 
triggerall = var(12) = 1
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
; ���Ⴊ�ݍ����ړ� (�O��)
[State -1, ChangeState]
type = ChangeState
value = 6200
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "F_z" 
triggerall = var(12) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "F_z" 
triggerall = var(12) = 1
trigger1 = statetype = C
trigger1 = ctrl
trigger2= (stateno=[400,440]) && movecontact

;---------------------------------------------------------------------------
; ���Ⴊ�ݍ����ړ� (���)
[State -1, ChangeState]
type = ChangeState
value = 6201
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "B_z"
triggerall = var(12) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2= (stateno=[400,440]) && movecontact
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "B_z"
triggerall = var(12) = 1
trigger1 = statetype = C
trigger1 = ctrl
trigger2= (stateno=[400,440]) && movecontact

;---------------------------------------------------------------------------
; ���Ⴊ�ݍ����ړ� 
[State -1, ChangeState]
type = ChangeState
value = 6999
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "z" 
triggerall = var(12) = 0
trigger1 = statetype = C
trigger1 = ctrl
;�n��a
[State -1, ChangeState]
type = ChangeState
value = 5410
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = command = "z" 
triggerall = var(12) = 1
trigger1 = statetype = C
trigger1 = ctrl

;---------------------------------------------------------------------------
; �󒆍����ړ� (���O��)
[State -1, ChangeState]
type = ChangeState
value = 6110
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "DF_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "DF_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact

;---------------------------------------------------------------------------
; �󒆍����ړ� (�����)
[State -1, ChangeState]
type = ChangeState
value = 6130
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "DB_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "DB_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact

;---------------------------------------------------------------------------
; �󒆍����ړ� (����)
[State -1, ChangeState]
type = ChangeState
value = 6150
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "UB_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "UB_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact

;---------------------------------------------------------------------------
; �󒆍����ړ� (��O��)
[State -1, ChangeState]
type = ChangeState
value = 6170
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "UF_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "UF_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact

;---------------------------------------------------------------------------
; �󒆍����ړ� (�O��)
[State -1, ChangeState]
type = ChangeState
value = 6100
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "F_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "F_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact

;---------------------------------------------------------------------------
; �󒆍����ړ� (����)
[State -1, ChangeState]
type = ChangeState
value = 6120
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "D_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "D_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact

;---------------------------------------------------------------------------
; �󒆍����ړ� (���)
[State -1, ChangeState]
type = ChangeState
value = 6140
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "B_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "B_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact

;---------------------------------------------------------------------------
; �󒆍����ړ� (���)
[State -1, ChangeState]
type = ChangeState
value = 6160
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "U_z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "U_z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl
trigger2= (stateno=[600,640]) && movecontact 

;---------------------------------------------------------------------------
; �󒆍����ړ� 
[State -1, ChangeState]
type = ChangeState
value = 6099
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "z"
triggerall = var(12) = 0
trigger1 = statetype = A
trigger1 = ctrl
;�󒆕a
[State -1, ChangeState]
type = ChangeState
value = 5420
TriggerAll = Var(40) != 1
TriggerAll = Var(33) = 0
triggerall = var(3) = [0,2]
triggerall = command = "z"
triggerall = var(12) = 1
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�W�J�����ړ���
[State -1, ChangeState]
type = ChangeState
value = 7000
TriggerAll = Var(40) = 1
TriggerAll = Var(33) = 0
triggerall = command = "z"
trigger1 = statetype != A
trigger1 = ctrl

;�W�J�����ړ���
[State -1, ChangeState]
type = ChangeState
value = 7010
TriggerAll = Var(40) = 1
TriggerAll = Var(33) = 0
triggerall = command = "z"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
; �������O�W�����v
[State -1, ChangeState]
type = ChangeState
value = 60
TriggerAll = Var(33) = 0
triggerall = statetype = S
triggerall = ctrl = 1
triggerall = command = "longjump"
trigger1 = prevstateno = 999
trigger2 = command = "hold_c"

;---------------------------------------------------------------------------
; �C�͗���
[State -1, ChangeState]
type = ChangeState
value = 999
TriggerAll = Var(33) = 0
TriggerAll = Var(20) = 0
triggerall = statetype != A
triggerall = Power < 9000 || fvar(12) > 0
triggerall = ctrl = 1
triggerall= stateno != [100,103]
trigger1 = command = "hold_c"

;---------------------------------------------------------------------------
;�u���b�L���O����
[State -1, hitoverride]
type = hitoverride
TriggerAll = Var(33) = 0
triggerall = statetype = S
triggerall = command = "fwd" && command != "back" && command != "up" && command != "down"
triggerall = movetype != A
triggerall = movetype != H
trigger1 = stateno=902 || stateno=903
trigger2 = stateno= 0
trigger3 = stateno= 10
trigger4 = stateno= 11
trigger5 = stateno= 12
trigger6 = stateno= 20
attr = SA,AA,AP
stateno = 902
slot = 0
time = ifelse((stateno=[150,153]),6,8)

;---------------------------------------------------------------------------
;�u���b�L���O���Ⴊ��
[State -1, hitoverride]
type = hitoverride
TriggerAll = Var(33) = 0
triggerall=(statetype=S&&command="down")||(statetype=C&&command="fwd")&&command!="back"&&command!="up"
triggerall = movetype != A
trigger1 = stateno=902 || stateno=903
trigger2 = stateno= 0
trigger3 = stateno= 10
trigger4 = stateno= 11
trigger5 = stateno= 12
trigger6 = stateno= 20
attr = C,AA,AP
stateno = 903
slot = 0
time = ifelse((stateno=[150,153]),6,8)

;---------------------------------------------------------------------------
;�u���b�L���O��
[State -1, hitoverride]
type = hitoverride
TriggerAll = Var(33) = 0
triggerall = command = "fwd" && command != "back" && command != "up" && command != "down"
triggerall = movetype != A
triggerall = statetype = A
trigger1 = stateno=904
trigger2 = stateno= 45
trigger3 = stateno= 50
trigger4 = stateno= 51
attr = SA,AA,AP
stateno = 904
forceair = 1
slot = 0
time = ifelse((stateno=[154,155]),6,8)


;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;������������������������������������������������������������������������
;������������������������������������������������������������������������
;������������������������������������������������������������������������
[State -1, Explod];�����ˁ@�y�����R�袋���z�y�����R�袋��(����)�z�y����̔w�ォ��R��(��)�z
type = Explod
triggerall = p2movetype = H
triggerall = numexplod(17000) = 0
trigger1 = p2stateno = 261 || p2stateno = 264
trigger2 = p2stateno = 291
anim = 17000
pos = -14, 2
postype = p2
sprpriority = -3
ontop = 1
ownpal = 1
id = 17000


[State -1, Explod];�ǌ��ˁ@ �y����̔w�ォ��R��(��)�z�y�V�����z�y���������L�b�N�̓���2�z�y�Ռ��g(��)�z
type = Explod
triggerall = p2movetype = H
triggerall = numexplod(17100) = 0
triggerall = P2Dist X > 0
trigger1 = p2stateno = 251 || p2stateno = 271
trigger2 = p2stateno = 281
anim = 17100
pos = 0, floor(screenpos y) -60
postype = front
facing = ifelse(facing = 1,1,-1)
sprpriority = -3
ontop = 1
id = 17100


[State -1, Explod];�ǌ��˓��ڂ̏Փ�
type = Explod
triggerall = p2movetype = H
triggerall = numexplod(17100) = 0
trigger1 = p2stateno = 266
anim = 17100
pos = 30, 50
postype = p2
facing = 1
sprpriority = -3
ontop = 1
id = 17100

[State -1, Explod];�ǌ��˓��ڂ̏Փ�
type = Explod
triggerall = p2movetype = H
triggerall = numexplod(17100) = 0
trigger1 = p2stateno = 268
anim = 17100
pos = 30, -50
postype = p2
facing = 1
sprpriority = -3
ontop = 1
id = 17100

;������������������������������������������������������������������������

[State 3310, Helper]
type = Helper
triggerall = numHelper(5503) = 0
trigger1 = p2stateno = 251 || p2stateno = 271
trigger2 = p2stateno = 261 || p2stateno = 266
trigger3 = p2stateno = 291 || p2stateno = 281
trigger4 = p2stateno = 264 || p2stateno = 3937
trigger5 = p2stateno = 268
name = "gegi"
ID = 5503
pos = 120,0
postype = left
stateno = 5503
ownpal = 1
size.xscale = 0.5
size.yscale = 0.5
supermovetime = 10000
pausemovetime = 10000
ignorehitpause = 1

[State -1, PlaySnd];����PlaySnd
type = PlaySnd
triggerall = p2movetype = H
triggerall = NumExplod(1111) = 1
trigger1 = p2stateno = 268
value = s700, 2
;channel = 4
;lowpriority = 2
ignorehitpause = 1
persistent=0

[State 1000, Explod]
type = RemoveExplod
trigger1 = p2stateno = 252 || p2stateno = 272
trigger2 = p2stateno = 262 || p2stateno = 267
trigger3 = p2stateno = 292 || p2stateno = 282
trigger4 = p2stateno = 265 || p2stateno = 3938
trigger5 = p2stateno = 269
ID = 1111
ignorehitpause = 1
supermovetime = 99999
pausemovetime = 99999



;������������������������������������������������������������������������

;�����ړ�
[State -2, ll]
type = PlaySnd
triggerall = Random = [300,599]
trigger1 = stateno = 5999
trigger2 = stateno = 6000
trigger3 = stateno = 6001
trigger4 = stateno = 6060
trigger5 = stateno = 6050
trigger6 = stateno = 6070
value = s5001,4
channel = 0
lowpriority = 3
persistent=0
ignorehitpause = 1


[State -2, ll]
type = PlaySnd
triggerall = Random = [600,999]
trigger1 = stateno = 6999
trigger2 = stateno = 6200
trigger3 = stateno = 6201
value = s5002,4
channel = 0
lowpriority = 3
persistent=0
ignorehitpause = 1

[State 6151, posadd]
type = Varset
trigger1 = StateType != A
var(3) = 0



;�����ړ�
[State -2, ll]
type = PlaySnd
triggerall = var(3) = 0
trigger1 = stateno = 6099
trigger2 = stateno = 6100
trigger3 = stateno = 6120
trigger4 = stateno = 6140
trigger5 = stateno = 6160
trigger6 = stateno = 6110
trigger7 = stateno = 6130
trigger8 = stateno = 6150
trigger9 = stateno = 6170
value = s5001,3
channel = 0
lowpriority = 3
persistent=0
ignorehitpause = 1

;�����ړ�
[State -2, ll]
type = PlaySnd
triggerall = var(3) = 1
trigger1 = stateno = 6099
trigger2 = stateno = 6100
trigger3 = stateno = 6120
trigger4 = stateno = 6140
trigger5 = stateno = 6160
trigger6 = stateno = 6110
trigger7 = stateno = 6130
trigger8 = stateno = 6150
trigger9 = stateno = 6170
value = s5001,1
channel = 1
lowpriority = 3
persistent=0
ignorehitpause = 1

;�����ړ�
[State -2, ll]
type = PlaySnd
triggerall = var(3) = 2
trigger1 = stateno = 6099
trigger2 = stateno = 6100
trigger3 = stateno = 6120
trigger4 = stateno = 6140
trigger5 = stateno = 6160
trigger6 = stateno = 6110
trigger7 = stateno = 6130
trigger8 = stateno = 6150
trigger9 = stateno = 6170
value = s5002,4
channel = 5
lowpriority = 3
persistent=0
ignorehitpause = 1


;�R�}���h
[State 240, Varset]
type = Varset
trigger1 = stateno != 240
var(24) = 0




;--------------------------------------
;��������������������������������������
;[Statedef 242]
[State 252, VelSet]
type = Varset
trigger1 = stateno != 242
trigger1 = var(26) != 0
var(26) = 0
persistent=0
ignorehitpause=1


;�J�E���^�[
;��������������������������������������
[State -1, PlaySnd];����PlaySnd
type = PlaySnd
triggerall = numexplod(16501) = 0
trigger1 = movehit = 1
trigger1 = var(30) = 1
value = s646, 0
ignorehitpause = 1

[State -1, Explod]
type = Explod
triggerall = numexplod(16501) = 0
trigger1 = movehit = 1
trigger1 = var(30) = 1
anim = 16501
pos = 0, -50
postype = p2
sprpriority = 3
ontop = 1
ownpal = 1
id = 16501
scale = 1.5, 1.5
ignorehitpause=1

[State 252, VelSet]
type = Varset
trigger1 = enemy,movetype = A
var(30) = 1
ignorehitpause=1

[State 252, VelSet]
type = Varset
trigger1 = enemy,movetype != A
var(30) = 0
ignorehitpause=1

;���o�T
;������������������������������������������������������������������������
; �N��������
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall  = stateno = 5120               ; �N��������
triggerall  = AnimTime = 0
trigger1  = var(16) >= 1000
trigger1  = var(16) < 3000
trigger2  = var(16) >= 3400
trigger2  = var(16) < 3500
value = var(16)
ctrl = 0
; �N��������
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
trigger1  = stateno = 5120               ; �N��������
trigger1  = AnimTime = 0
trigger1  = var(16) = 3000
trigger1  = Power >= 3000
value = var(16)
ctrl = 0
; �N��������
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall  = stateno = 5120               ; �N��������
triggerall  = AnimTime = 0
trigger1  = var(16) >= 3100
trigger1  = var(16) < 3540
trigger1  = Power >= 1000
value = var(16)
ctrl = 0
; �N��������
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall  = stateno = 5120               ; �N��������
triggerall  = AnimTime = 0
trigger1  = var(16) >= 3540
trigger1  = var(16) < 3980
trigger1  = power >= 3000
value = var(16)
ctrl = 0

; ��炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5001               ; ��炢��
triggerall   = HitOver
trigger1  = var(16) >= 1000
trigger1  = var(16) < 3000
trigger2  = var(16) >= 3400
trigger2  = var(16) < 3500
value = var(16)
ctrl = 0
; ��炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5001               ; ��炢��
triggerall   = HitOver
trigger1  = var(16) = 3000
trigger1  = Power >= 3000
value = var(16)
ctrl = 0
; ��炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5001               ; ��炢��
triggerall   = HitOver
trigger1  = var(16) >= 3100
trigger1  = var(16) < 3540
trigger1  = Power >= 1000
value = var(16)
ctrl = 0
; ��炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5001               ; ��炢��
triggerall   = HitOver
trigger1  = var(16) >= 3540
trigger1  = var(16) < 3980
trigger1  = power >= 3000
value = var(16)
ctrl = 0

; ����炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5011               ; ����炢��
triggerall   = HitOver
trigger1  = var(16) >= 1000
trigger1  = var(16) < 3000
trigger2  = var(16) >= 3400
trigger2  = var(16) < 3500
value = var(16)
ctrl = 0
; ����炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5011               ; ����炢��
triggerall   = HitOver
trigger1  = var(16) = 3000
trigger1  = Power >= 3000
value = var(16)
ctrl = 0
; ����炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5011               ; ����炢��
triggerall   = HitOver
trigger1  = var(16) >= 3100
trigger1  = var(16) < 3540
trigger1  = Power >= 1000
value = var(16)
ctrl = 0
; ����炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 5011               ; ����炢��
triggerall   = HitOver
trigger1  = var(16) >= 3540
trigger1  = var(16) < 3980
trigger1  = power >= 3000
value = var(16)
ctrl = 0

; �󒆋�炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 5021               ; �󒆋�炢��
triggerall   = HitOver
trigger1  = var(17) >= 1000
trigger1  = var(17) < 3000
trigger2  = var(17) >= 3400
trigger2  = var(17) < 3500
value = var(17)
ctrl = 0
; �󒆋�炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 5021               ; �󒆋�炢��
triggerall   = HitOver
trigger1  = var(17) = 3000
trigger1  = Power >= 3000
value = var(17)
ctrl = 0
; �󒆋�炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 5021               ; �󒆋�炢��
triggerall   = HitOver
trigger1  = var(17) >= 3100
trigger1  = var(17) < 3540
trigger1  = Power >= 1000
value = var(17)
ctrl = 0
; �󒆋�炢��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 5021               ; �󒆋�炢��
triggerall   = HitOver
trigger1  = var(17) >= 3540
trigger1  = var(17) < 3980
trigger1  = power >= 3000
value = var(17)
ctrl = 0

; �K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 151               ; �K�[�h��
triggerall   = HitOver
trigger1  = var(16) >= 1000
trigger1  = var(16) < 3000
trigger2  = var(16) >= 3400
trigger2  = var(16) < 3500
value = var(16)
ctrl = 0
; �K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 151               ; �K�[�h��
triggerall   = HitOver
trigger1  = var(16) = 3000
trigger1  = Power >= 3000
value = var(16)
ctrl = 0
; �K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 151               ; �K�[�h��
triggerall   = HitOver
trigger1  = var(16) >= 3100
trigger1  = var(16) < 3540
trigger1  = Power >= 1000
value = var(16)
ctrl = 0
; �K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 151               ; �K�[�h��
triggerall   = HitOver
trigger1  = var(16) >= 3540
trigger1  = var(16) < 3980
trigger1  = power >= 3000
value = var(16)
ctrl = 0

; ���K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 153               ; ���K�[�h��
triggerall   = HitOver
trigger1  = var(16) >= 1000
trigger1  = var(16) < 3000
trigger2  = var(16) >= 3400
trigger2  = var(16) < 3500
value = var(16)
ctrl = 0
; ���K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 153               ; ���K�[�h��
triggerall   = HitOver
trigger1  = var(16) = 3000
trigger1  = Power >= 3000
value = var(16)
ctrl = 0
; ���K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 153               ; ���K�[�h��
triggerall   = HitOver
trigger1  = var(16) >= 3100
trigger1  = var(16) < 3540
trigger1  = Power >= 1000
value = var(16)
ctrl = 0
; ���K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = S || statetype = C
triggerall   = stateno = 153               ; ���K�[�h��
triggerall   = HitOver
trigger1  = var(16) >= 3540
trigger1  = var(16) < 3980
trigger1  = power >= 3000
value = var(16)
ctrl = 0

; �󒆃K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 155               ; �󒆃K�[�h��
triggerall   = HitOver
trigger1  = var(17) >= 1000
trigger1  = var(17) < 3000
trigger2  = var(17) >= 3400
trigger2  = var(17) < 3500
value = var(17)
ctrl = 0
; �󒆃K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 155               ; �󒆃K�[�h��
triggerall   = HitOver
trigger1  = var(17) = 3000
trigger1  = Power >= 3000
value = var(17)
ctrl = 0
; �󒆃K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 155               ; �󒆃K�[�h��
triggerall   = HitOver
trigger1  = var(17) >= 3100
trigger1  = var(17) < 3540
trigger1  = Power >= 1000
value = var(17)
ctrl = 0
; �󒆃K�[�h��
[State 5120, 7]
type = ChangeState
TriggerAll = Var(33) = 0
TriggerAll = var(11) = 1 || fvar(12) < 5
triggerall   = statetype = A
triggerall   = stateno = 155               ; �󒆃K�[�h��
triggerall   = HitOver
trigger1  = var(17) >= 3540
trigger1  = var(17) < 3980
trigger1  = power >= 3000
value = var(17)
ctrl = 0

;------
;���Z�b�g
[State -1, Varset]
type = Varset
trigger1 = stateno != 151
trigger1 = stateno != 153
trigger1 = stateno != 154
trigger1 = stateno != 5120
trigger2 = var(28) >= 10
var(16) = 0
ignorehitpause=1
[State -1, Varset]
type = Varset
trigger1 = stateno != 151
trigger1 = stateno != 153
trigger1 = stateno != 154
trigger1 = stateno != 5120
trigger2 = var(29) >= 10
var(17) = 0
ignorehitpause=1

[State -1, Varset]
type = Varadd
trigger1 = var(16) != 0
var(28) = 1
ignorehitpause=1
[State -1, Varset]
type = Varset
trigger1 = var(16) = 0
var(28) = 0
ignorehitpause=1
[State -1, Varset]
type = Varadd
trigger1 = var(17) != 0
var(29) = 1
ignorehitpause=1
[State -1, Varset]
type = Varset
trigger1 = var(17) = 0
var(29) = 0
ignorehitpause=1
;------
